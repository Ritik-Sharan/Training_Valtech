﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace FoodCourtManagementEntity
{
    public class Sale
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public int FoodQuantity { get; set; }
        public int SalesAmount { get; set; }

        [ForeignKey("Item")]
        public int FoodId { get; set; }
        public Item Item { get; set; }
    }
}
