﻿using FoodCourtManagementData;
using FoodCourtManagementEntity;
using FoodCourtManagementPresentation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text.Encodings.Web;
using System.Xml.Serialization;

namespace FoodCourtManagement
{
    public class Program
    {
        static void Main(string[] args)
        {
            //FoodDbContext db = new FoodDbContext();
            //ItemDAL itemDAL = new ItemDAL();

            ////how to deserialize

            //var reader = new StreamReader("items.xml");
            //var result = (List<Item>)serializer.Deserialize(filestr);
            //foreach (var item in result)
            //{
            //    Console.WriteLine(item);
            //}




            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Welcome to Food Court Management System");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Manage Food Items\n" +
            "2) Press 2 to Manage Food Category\n" +
            "3) Press 3 to Manage Sales\n" +
            "4) Press 4 to Show Reports\n" +
            "5) Press 5 to exit");

            int inputCase = int.Parse(Console.ReadLine());
            switch (inputCase)
            {
                case 1:
                    ItemPL itemPL = new ItemPL();
                    itemPL.FoodItemSection();
                    break;
                case 2:
                    CategoryPL categoryPL = new CategoryPL();
                    categoryPL.FoodCategorySection();
                    break;
                case 3:
                    SalePL salePL = new SalePL();
                    salePL.SalesSection();
                    break;
                case 4:
                    ReportPL reportPL = new ReportPL();
                    reportPL.ReportSection();
                    break;
                case 5:
                    break;
            }
            Console.Read();
        }
    }
}
