﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FoodCourtManagementData.Migrations
{
    public partial class FoodDbCourt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
