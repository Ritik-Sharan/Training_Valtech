﻿using FoodCourtManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodCourtManagementData
{
    public class SaleDAL
    {
        FoodDbContext db = null;
        public string AddSaleDAL(Sale sale)
        {
            db = new FoodDbContext();
            List<Item> itemList = db.items.ToList();
            var result = (from obj in itemList
                          where obj.Id == sale.Id
                          select obj.ItemPrice).FirstOrDefault();
            sale.SalesAmount = sale.FoodQuantity * result;
            db.sales.Add(sale);
            db.SaveChanges();
            return "Saved";
        }
        public string UpdateSaleDAL(Sale sale)
        {
            db = new FoodDbContext();
            List<Item> itemList = db.items.ToList();
            var result = (from obj in itemList
                          where obj.Id == sale.Id
                          select obj.ItemPrice).FirstOrDefault();
            sale.SalesAmount = sale.FoodQuantity * result;
            db.Entry(sale).State = EntityState.Modified;
            db.SaveChanges();
            return "Updated";
        }
        public List<Sale> ShowAllDAL()
        {
            db = new FoodDbContext();
            List<Sale> SaleList = db.sales.ToList();

            return SaleList;
        }
        public List<Sale> ShowAllByFoodIdDAL(int type)
        {
            db = new FoodDbContext();
            List<Sale> saleList = db.sales.ToList();

            //linq query-select * from movies where movietype='type'
            var result = from sal in saleList
                         where sal.FoodId == type
                         //group items by items.ItemType into val
                         orderby sal.FoodId
                         select sal;
            List<Sale> saleResult = new List<Sale>();
            foreach (var sal in result)//linq queary execution
            {
                saleList.Add(sal);
            }
            return saleResult;
        }
    }
}
