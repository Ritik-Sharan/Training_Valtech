﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementData
{
    internal class SaleDAL
    {
    }
}
