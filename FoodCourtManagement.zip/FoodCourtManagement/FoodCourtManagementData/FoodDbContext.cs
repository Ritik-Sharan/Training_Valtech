﻿using FoodCourtManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;

namespace FoodCourtManagementData
{
    public class FoodDbContext:DbContext
    {
        public DbSet<Item> items { get; set; }
        public DbSet<Category> categories { get; set; }
        public DbSet<Sale> sales { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {
            dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LTC2125;Initial Catalog=FoodDb;Integrated Security=True;");
        }
    }
}
