﻿using FoodCourtManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodCourtManagementData
{
    public class CategoryDAL
    {
        FoodDbContext db = null;
        public string AddCategoryDAL(Category category)
        {
            db = new FoodDbContext();
            db.categories.Add(category);
            db.SaveChanges();
            return "Saved";
        }
        public string UpdateCategoryDAL(Category category)
        {
            db = new FoodDbContext();
            db.Entry(category).State = EntityState.Modified;
            db.SaveChanges();
            return "Updated";
        }
        public List<Category> ShowAllDAL()
        {
            db = new FoodDbContext();
            List<Category> CategoryList = db.categories.ToList();

            return CategoryList;
        }
        public List<Category> ShowAllByCategoryNameDAL(string type)
        {
            db = new FoodDbContext();
            List<Category> categoryList = db.categories.ToList();

            //linq query-select * from movies where movietype='type'
            var result = from cat in categoryList
                         where cat.Name == type
                         //group items by items.ItemType into val
                         orderby cat.Name
                         select new Category
                         {
                             Id = cat.Id,
                             Name = cat.Name
                         };
            List<Category> categoryResult = new List<Category>();
            foreach (var cat in result)//linq queary execution
            {
                categoryResult.Add(cat);
            }
            return categoryResult;
        }
    }
}
