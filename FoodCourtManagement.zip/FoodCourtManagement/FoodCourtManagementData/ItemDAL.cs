﻿using FoodCourtManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodCourtManagementData
{
    public class ItemDAL
    {
        FoodDbContext db = null;
        public string AddItemDAL(Item item)
        {
            db = new FoodDbContext();
            db.items.Add(item);
            db.SaveChanges();
            return "Saved";
        }
        public string UpdateItemDAL(Item item)
        {
            db = new FoodDbContext();
            db.Entry(item).State = EntityState.Modified;
            db.SaveChanges();
            return "Updated";
        }
        public List<Item> ShowAllDAL()
        {
            db = new FoodDbContext();
            List<Item> movieList = db.items.ToList();
            return movieList;
        }
        public List<Item> ShowAllByItemTypeDAL(string type)
        {
            db = new FoodDbContext();
            List<Item> itemList = db.items.ToList();

            //linq query-select * from movies where movietype='type'
            var result = from items in itemList
                         where items.ItemType == type
                         //group items by items.ItemType into val
                         orderby items.Name
                         select new Item
                         {
                             Id = items.Id,
                             Name = items.Name
                         };
            List<Item> itemResult = new List<Item>();
            foreach (var item in result)//linq queary execution
            {
                itemResult.Add(item);
            }
            return itemResult;
        }

    }
}
