﻿using FoodCourtManagementData;
using FoodCourtManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementBusiness
{
    public class CategoryBLL
    {
        CategoryDAL categoryDAL = new CategoryDAL();
        public string AddCategoryBLL(Category category)
        {
            return categoryDAL.AddCategoryDAL(category);
        }
        public string UpdateCategoryBLL(Category category)
        {
            return categoryDAL.UpdateCategoryDAL(category);
        }
        public List<Category> ShowAllBLL()
        {
            return categoryDAL.ShowAllDAL();
        }
        public List<Category> ShowAllByCategoryNameBLL(string type)
        {
            return categoryDAL.ShowAllByCategoryNameDAL(type);
        }
    }
}
