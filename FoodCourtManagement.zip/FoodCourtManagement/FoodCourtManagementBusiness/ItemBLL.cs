﻿using FoodCourtManagementData;
using FoodCourtManagementEntity;
using System;
using System.Collections.Generic;

namespace FoodCourtManagementBusiness
{
    public class ItemBLL
    {
        ItemDAL itemDAL = new ItemDAL();
        public string AddItemBLL(Item item)
        {
            return itemDAL.AddItemDAL(item);
        }
        public string UpdateItemBLL(Item item)
        {
            return itemDAL.UpdateItemDAL(item);
        }
        public List<Item> ShowAllBLL()
        {
            return itemDAL.ShowAllDAL();
        }
        public List<Item> ShowAllByItemTypeBLL(string type)
        {
            return itemDAL.ShowAllByItemTypeDAL(type);
        }
    }
}
