﻿using FoodCourtManagementData;
using FoodCourtManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementBusiness
{
    public class SaleBLL
    {
        SaleDAL saleDAL = new SaleDAL();
        public string AddSaleBLL(Sale sale)
        {
            return saleDAL.AddSaleDAL(sale);
        }
        public string UpdateSaleBLL(Sale sale)
        {
            return saleDAL.UpdateSaleDAL(sale);
        }
        public List<Sale> ShowAllBLL()
        {
            return saleDAL.ShowAllDAL();
        }
        public List<Sale> ShowAllByFoodIdBLL(int type)
        {
            return saleDAL.ShowAllByFoodIdDAL(type);
        }
    }
}
