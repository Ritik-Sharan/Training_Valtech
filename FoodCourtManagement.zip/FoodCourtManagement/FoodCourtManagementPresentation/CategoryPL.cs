﻿using FoodCourtManagementBusiness;
using FoodCourtManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementPresentation
{
    public class CategoryPL
    {
        public void AddCategory()
        {
            CategoryBLL categoryBLL = new CategoryBLL();
            Category category = new Category();
            Console.Write("Enter Category Name:");
            category.Name = Console.ReadLine();
            Console.Write("Enter Food Id:");
            category.FoodId = Convert.ToInt32(Console.ReadLine());

            categoryBLL.AddCategoryBLL(category);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Category Added Successfully............");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void UpdateCategory()
        {
            CategoryBLL categoryBLL = new CategoryBLL();
            Category category = new Category();
            Console.Write("Enter Category Id:");
            category.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter Category Name:");
            category.Name = Console.ReadLine();
            Console.Write("Enter Food Id:");
            category.FoodId = Convert.ToInt32(Console.ReadLine());

            categoryBLL.UpdateCategoryBLL(category);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Category Updated Successfully............");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void ShowAllCategory()
        {
            CategoryBLL categoryBLL=new CategoryBLL();
            List<Category> categories = categoryBLL.ShowAllBLL();
            foreach (var cat in categories)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("Id:" + cat.Id);
                Console.WriteLine("Name:" + cat.Name);
                Console.WriteLine("FoodId:" + cat.FoodId);
                Console.WriteLine("--------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void ShowAllByCategoryName()
        {
            CategoryBLL categoryBLL = new CategoryBLL();
            Console.WriteLine("Enter Movie Type:");
            string itemType = Console.ReadLine();
            List<Category> categories = categoryBLL.ShowAllByCategoryNameBLL(itemType);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            foreach (var cat in categories)
            {
                Console.WriteLine("Id:" + cat.Id);
                Console.WriteLine("Name:" + cat.Name);
            }
            Console.WriteLine("----------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }
        private void GetCategoryMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Add New Food Category\n" +
            "2) Press 2 to Edit the Existing Food Category\n" +
            "3) Press 3 to View Details of the Food Category\n" +
            "4) Press 4 to Show Listing of All Food Category\n" +
            "5) Press 5 to exit");
        }
        public void FoodCategorySection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("----------------Manage-Food-Category----------------");
            GetCategoryMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    AddCategory();
                    FoodCategorySection();
                    break;
                case 2:
                    UpdateCategory();
                    FoodCategorySection();
                    break;
                case 3:
                    ShowAllCategory();
                    FoodCategorySection();
                    break;
                case 4:
                    ShowAllByCategoryName();
                    FoodCategorySection();
                    break;
                case 5:
                    break;
            }
        }
    }
}
