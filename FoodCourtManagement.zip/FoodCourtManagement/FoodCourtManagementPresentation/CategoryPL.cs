﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementPresentation
{
    public class CategoryPL
    {
        private void GetCategoryMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Add New Food Category\n" +
            "2) Press 2 to Edit the Existing Food Category\n" +
            "3) Press 3 to View Details of the Food Category\n" +
            "4) Press 4 to Show Listing of All Food Category\n" +
            "5) Press 5 to exit");
        }
        public void FoodCategorySection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("----------------Manage-Food-Category----------------");
            GetCategoryMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    //AddMovie();
                    FoodCategorySection();
                    break;
                case 2:
                    //ShowAllMovies();
                    FoodCategorySection();
                    break;
                case 3:
                    //DeleteMovie();
                    FoodCategorySection();
                    break;
                case 4:
                    //ShowAllByMovieType();
                    FoodCategorySection();
                    break;
                case 5:
                    break;
            }
        }
    }
}
