﻿using FoodCourtManagementBusiness;
using FoodCourtManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementPresentation
{
    public class SalePL
    {
        private void GetSalesMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Add New Sales\n" +
            "2) Press 2 to Edit the Existing Sales\n" +
            "3) Press 3 to View Details of the Sales\n" +
            "4) Press 4 to Show Listing of All Sales\n" +
            "5) Press 5 to exit");
        }
        public void SalesSection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("----------------Manage-Sales----------------");
            GetSalesMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    AddSale();
                    SalesSection();
                    break;
                case 2:
                    UpdateSale();
                    SalesSection();
                    break;
                case 3:
                    ShowAllSale();
                    SalesSection();
                    break;
                case 4:
                    ShowAllByFoodId();
                    SalesSection();
                    break;
                case 5:
                    break;
            }
        }
        public void AddSale()
        {
            SaleBLL saleBLL = new SaleBLL();
            Sale sale = new Sale();
            Console.Write("Enter Food Id:");
            sale.FoodId =Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Food Quantity:");
            sale.FoodQuantity = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Sales Amount:");
            sale.SalesAmount = Convert.ToInt32(Console.ReadLine());

            saleBLL.AddSaleBLL(sale);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Sales Added Successfully............");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void UpdateSale()
        {
            SaleBLL saleBLL = new SaleBLL();
            Sale sale = new Sale();
            Console.Write("Enter Id:");
            sale.Id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Food Id:");
            sale.FoodId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Food Quantity:");
            sale.FoodQuantity = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Sales Amount:");
            sale.SalesAmount = Convert.ToInt32(Console.ReadLine());

            saleBLL.UpdateSaleBLL(sale);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Sales Updated Successfully............");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void ShowAllSale()
        {
            SaleBLL saleBLL = new SaleBLL();
            List<Sale> sales = saleBLL.ShowAllBLL();
            foreach (var sal in sales)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("Id:" + sal.Id);
                Console.WriteLine("FoodId:" + sal.FoodId);
                Console.WriteLine("Food Quantity:" + sal.FoodQuantity);
                Console.WriteLine("Sale Amount:" + sal.SalesAmount);
                Console.WriteLine("--------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void ShowAllByFoodId()
        {
            SaleBLL saleBLL = new SaleBLL();
            Console.WriteLine("Enter Food Id:");
            int foodId = Convert.ToInt32(Console.ReadLine());
            List<Sale> sales = saleBLL.ShowAllByFoodIdBLL(foodId);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            foreach (var sal in sales)
            {
                Console.WriteLine("Id:" + sal.Id);
                Console.WriteLine("Sale Amount:" + sal.SalesAmount);
            }
            Console.WriteLine("----------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
