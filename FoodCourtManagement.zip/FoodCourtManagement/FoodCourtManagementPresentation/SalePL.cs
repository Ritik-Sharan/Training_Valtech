﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementPresentation
{
    public class SalePL
    {
        private void GetSalesMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Add New Sales\n" +
            "2) Press 2 to Edit the Existing Sales\n" +
            "3) Press 3 to View Details of the Sales\n" +
            "4) Press 4 to Show Listing of All Sales\n" +
            "5) Press 5 to exit");
        }
        public void SalesSection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("----------------Manage-Sales----------------");
            GetSalesMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    //AddMovie();
                    SalesSection();
                    break;
                case 2:
                    //ShowAllMovies();
                    SalesSection();
                    break;
                case 3:
                    //DeleteMovie();
                    SalesSection();
                    break;
                case 4:
                    //ShowAllByMovieType();
                    SalesSection();
                    break;
                case 5:
                    break;
            }
        }
    }
}
