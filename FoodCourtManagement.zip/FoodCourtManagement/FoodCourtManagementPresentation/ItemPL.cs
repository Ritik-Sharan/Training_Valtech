﻿using FoodCourtManagementBusiness;
using FoodCourtManagementEntity;
using System;
using System.Collections.Generic;

namespace FoodCourtManagementPresentation
{
    public class ItemPL
    {
        public void AddItem()
        {
            ItemBLL itemBLL = new ItemBLL();
            Item item = new Item();
            Console.Write("Enter Item Name:");
            item.Name = Console.ReadLine();
            Console.Write("Enter Item Price:");
            item.ItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Item Type:");
            item.ItemType = Console.ReadLine();
            itemBLL.AddItemBLL(item);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Item Added Successfully............");
            Console.ForegroundColor = ConsoleColor.White;
            //Console.Write(msg);
        }
        public void UpdateItem()
        {
            ItemBLL itemBLL = new ItemBLL();
            Item item = new Item();
            Console.Write("Enter Item Id:");
            item.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter Item Name:");
            item.Name = Console.ReadLine();
            Console.Write("Enter Item Price:");
            item.ItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Item Type:");
            item.ItemType = Console.ReadLine();

            itemBLL.UpdateItemBLL(item);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Item Updated Successfully............");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void ShowAllItems()
        {
            ItemBLL itemBLL = new ItemBLL();
            List<Item> items = itemBLL.ShowAllBLL();
            foreach (var item in items)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("Id:" + item.Id);
                Console.WriteLine("Name:" + item.Name);
                Console.WriteLine("Price:" + item.ItemPrice);
                Console.WriteLine("Type:" + item.ItemType);
                Console.WriteLine("--------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void ShowAllByItemType()
        {
            ItemBLL itemBLL = new ItemBLL();
            Console.WriteLine("Enter Movie Type:");
            string itemType = Console.ReadLine();
            List<Item> items = itemBLL.ShowAllByItemTypeBLL(itemType);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            foreach (var item in items)
            {
                Console.WriteLine("Id:" + item.Id);
                Console.WriteLine("Name:" + item.Name);
            }
            Console.WriteLine("----------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }
        private void GetItemMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Add New Food Items\n" +
            "2) Press 2 to Edit the Existing Food Items\n" +
            "3) Press 3 to View Details of the Food Items\n" +
            "4) Press 4 to Show Listing of All Food Items By Item Type\n" +
            "5) Press 5 to exit");
        }
        public void FoodItemSection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("----------------Manage-Food-Items----------------");
            GetItemMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    AddItem();
                    FoodItemSection();
                    break;
                case 2:
                    UpdateItem();
                    FoodItemSection();
                    break;
                case 3:
                    ShowAllItems();
                    FoodItemSection();
                    break;
                case 4:
                    ShowAllByItemType();
                    FoodItemSection();
                    break;
                case 5:
                    break;
            }
        }
    }
}
