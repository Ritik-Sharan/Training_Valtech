﻿using FoodCourtManagementData;
using FoodCourtManagementEntity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace FoodCourtManagementPresentation
{
    public class ReportPL
    {
        FoodDbContext db = null;
        ItemPL itemPL = new ItemPL();
        CategoryPL categoryPL = new CategoryPL();
        SalePL salePL = new SalePL();
        private void GetReportMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Show Report of All Food Items\n" +
            "2) Press 2 to Show Report of All Food Category\n" +
            "3) Press 3 to Show Report of All Sales\n" +
            "4) Press 4 to exit");
        }
        public void ReportSection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("-------Reports-of-the-Food-Court-Managemenet-System-------");
            GetReportMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    itemPL.ShowAllItems();
                    ItemReport();
                    ReportSection();
                    break;
                case 2:
                    categoryPL.ShowAllCategory();
                    CategoryReport();
                    ReportSection();
                    break;
                case 3:
                    //salePL.ShowAllSale();
                    SalesReportJSON();
                    ReportSection();
                    break;
                case 4:
                    break;

            }
        }
        public string ItemReport()
        {
            db = new FoodDbContext();
            List<Item> ItemList = db.items.ToList();

            XmlSerializer serializer = new XmlSerializer(typeof(List<Item>));
            FileStream filestr = new FileStream("items.xml", FileMode.Create);
            serializer.Serialize(filestr, ItemList);
            filestr.Close();

            var json = JsonConvert.SerializeObject(ItemList);
            File.WriteAllText("item.json", json);
            Console.WriteLine("Items JSON and Xml File Created Successfully..............");
            return "";
        }
        public string CategoryReport()
        {
            db = new FoodDbContext();
            List<Category> categoryList = db.categories.ToList();

            XmlSerializer serializer = new XmlSerializer(typeof(List<Category>));
            FileStream filestr = new FileStream("categories.xml", FileMode.Create);
            serializer.Serialize(filestr, categoryList);
            filestr.Close();

            var json = JsonConvert.SerializeObject(categoryList);
            File.WriteAllText("category.json", json);
            Console.WriteLine("Categories JSON and Xml File Created Successfully..............");
            return "";
        }
        public string SalesReportJSON()
        {
            db = new FoodDbContext();
            List<Sale> salelist = db.sales.ToList();

            XmlSerializer serializer = new XmlSerializer(typeof(List<Category>));
            FileStream filestr = new FileStream("categories.xml", FileMode.Create);
            serializer.Serialize(filestr, salelist);
            filestr.Close();

            var json = JsonConvert.SerializeObject(salelist);
            File.WriteAllText("sale.json", json);
            Console.WriteLine("Sales JSON and Xml File Created Successfully..............");
            return "";
        }
    }
}
