﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagementPresentation
{
    public class ReportPL
    {
        private void GetReportMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Show Report of All Food Items\n" +
            "2) Press 2 to Show Report of All Food Category\n" +
            "3) Press 3 to Show Report of All Sales\n" +
            "4) Press 4 to exit");
        }
        public void ReportSection()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("-------Reports-of-the-Food-Court-Managemenet-System-------");
            GetReportMenu();
            int inputCaseBook = int.Parse(Console.ReadLine());
            switch (inputCaseBook)
            {
                case 1:
                    //AddMovie();
                    ReportSection();
                    break;
                case 2:
                    //ShowAllMovies();
                    ReportSection();
                    break;
                case 3:
                    //DeleteMovie();
                    ReportSection();
                    break;
                case 4:
                    break;

            }
        }
    }
}
