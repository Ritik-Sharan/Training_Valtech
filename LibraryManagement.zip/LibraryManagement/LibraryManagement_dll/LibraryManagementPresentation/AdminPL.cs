﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementBussiness;
using LibraryManagementEntity;

namespace LibraryManagementPresentation
{
    public class AdminPl
    {
        private void GetAdminMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Admin-Section----------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to show book section");
            Console.WriteLine("2) Press 2 to show user section");
            Console.WriteLine("3) Press 3 to show request sectrion");
            Console.WriteLine("3) Press 4 to show accepted sectrion");
            Console.Write("3) Press 5 to ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("logout");
            Console.ForegroundColor = ConsoleColor.White;
            var input = Convert.ToInt32(Console.ReadLine());
            if (input == 1)
            {
                BookPL bkpl = new BookPL();
                bkpl.BookSection();
            }
        }
        public bool AdminLogin()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Admin-Login----------");
            Console.ForegroundColor= ConsoleColor.White;
            Console.Write("Enter Admin Email : ");
            string email = Console.ReadLine();
            Console.Write("Enter Admin Password : ");
            string password = Console.ReadLine();

            AdminBLL bll= new AdminBLL();
            bool status=bll.AdminLogin(email, password);

            if (status)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Successfully logged in !!");
            }
            else
                Console.WriteLine("Invalid Credentials");
            return status;
        }

        public bool AdminSection()
        {
            GetAdminMenu();
            return true;
        }
    }
}
