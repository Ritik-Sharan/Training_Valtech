﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementBussiness;
using LibraryManagementEntity;

namespace LibraryManagementPresentation
{
    public class BookPL
    {
        //Book book = null;
        private void GetBookMenu()
        {
         
            
        }
        public void AddBook()
        {
            Book book = new Book();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter book details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter BookAuthor : ");
            book.BookAuthor = Console.ReadLine();
            Console.WriteLine("Enter BookCopies : ");
            book.BookCopies = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter BookId : ");
            book.BookId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Bookname : ");
            book.BookName = Console.ReadLine();

            BookBLL bookBLL = new BookBLL();
            string msg = bookBLL.AddBookBll(book);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Book added successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public string BookSection()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Book-Section----------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to add a book");
            Console.WriteLine("2) Press 2 to update a book");
            Console.WriteLine("3) Press 3 to delete a book");
            Console.WriteLine("4) Press 4 to show all book");
            Console.WriteLine("5) Press 5 to exit");
            var input = Convert.ToInt32(Console.ReadLine());


            switch (input)
            {
                case 1:
                    {
                        AddBook();
                        BookSection();
                        break;
                    }
                case 2:
                    {
                        UpdateBook();
                        BookSection();
                        break;
                    }
                case 3:
                    {
                        RemoveBook();
                        BookSection();
                        break;
                    }
                case 4:
                    {
                        GetAllBook();
                        BookSection();
                        break;
                    }
            }
            return "";
        }
        public void GetAllBook()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("------------------------------------Book-List-------------------------------------");
            Console.WriteLine("--Id----Name----------------------------Author--------------------------Copies----");
            Console.ForegroundColor = ConsoleColor.White;

            BookBLL bookBLL = new BookBLL();
            List<Book> bookBLLList = bookBLL.GetAllBookBll();
            foreach (var item in bookBLLList)
                {
                    Console.WriteLine("  "+item.BookId + "\t" + item.BookName + "\t" + item.BookAuthor + "\t" + item.BookCopies);
                }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("----------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void UpdateBook()
        {
            Book book = new Book();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter book details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter BookAuthor : ");
            book.BookAuthor = Console.ReadLine();
            Console.WriteLine("Enter BookCopies : ");
            book.BookCopies = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter BookId : ");
            book.BookId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Bookname : ");
            book.BookName = Console.ReadLine();

            BookBLL bookBLL= new BookBLL();
            string msg = bookBLL.UpdateBookBll(book);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Book updated successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }

        public void RemoveBook()
        {
            Book book = new Book();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter book details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter BookId : ");
            book.BookId = Convert.ToInt32(Console.ReadLine());

            BookBLL bookBLL = new BookBLL();
            string msg = bookBLL.RemoveBookBLL(book);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Book deleted successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
