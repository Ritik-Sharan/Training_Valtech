﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementData;
using LibraryManagementEntity;

namespace LibraryManagementBussiness
{
    public class BookBLL
    {
        public static List<Book> dalBook;
        BookDAL bookd = new BookDAL();

        public string AddBookBll(Book book)
        {
            return bookd.AddBooksDAL(book);
        }

        public List<Book> GetAllBookBll()
        {
             return bookd.GetAllBooksDAL();
        }
        public string UpdateBookBll(Book book)
        {
            return bookd.UpdateBooksDal(book);
        }
        public string RemoveBookBLL(Book book)
        {
            return bookd.RemoveBooksDAL(book);
        }

    }
}
