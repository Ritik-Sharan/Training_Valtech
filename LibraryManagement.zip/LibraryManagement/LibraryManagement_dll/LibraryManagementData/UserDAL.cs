﻿using LibraryManagementEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagementData
{
    public class UserDAL
    {
        public List<ReceivedBook> receivedBooks;

        public List<RequestedBook> requestedBooks;

        public List<User> users;

        public List<RequestedBook> AcceptRequestDAL()
        {
            return requestedBooks;
        }
        public List<User> AddUsersDAL()
        {
            return users;
        }
        public List<ReceivedBook> DeleteReceivedDAL()
        {
            return receivedBooks;
        }
        public List<User> GetAllUsersDAL()
        {
            return users;
        }
        public List<ReceivedBook> GetReceivedBookDAL()
        {
            return receivedBooks;
        }
        public List<RequestedBook> GetRequestBookDAL()
        {
            return requestedBooks;
        }
        public List<User> RemoveUsersDAL()
        {
            return users;
        }
        public List<RequestedBook> RequestBookDAL()
        {
            return requestedBooks;
        }
        public List<User> UpdateUsersDAL()
        {
            return users;
        }
    }
}
