﻿using LibraryManagementEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml.Serialization;
using System.IO;

namespace LibraryManagementData
{
    public class BookDAL
    {
        public static List<Book> books;
        public static string sqlcon = "Data Source=VDC01LLAP2298;Initial Catalog=LibraryManagement;Integrated Security=True;";

        public string AddBooksDAL(Book book)
        {
            #region connected approach
            //var msg = "";
            //SqlConnection con = new SqlConnection(sqlcon);
            //SqlCommand cmd = new SqlCommand("Insert into book values('" + book.BookAuthor + "'," + book.BookCopies + "," + book.BookId + ",'" + book.BookName + "')", con);
            //con.Open();
            //int row = cmd.ExecuteNonQuery();
            //con.Close();
            //if (row > 0)
            //    msg = "Inserted";

            //return msg;
            #endregion

            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Insert into book values('" + book.BookAuthor + "'," + book.BookCopies + "," + book.BookId + ",'" + book.BookName + "')", con);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            adp.Fill(dt);

            msg = "Inserted";
            return msg;
            #endregion

        }
        public List<Book> GetAllBooksDAL()
        {
            #region connected approach
            //SqlConnection con = new SqlConnection(sqlcon);
            //SqlCommand cmd = new SqlCommand("Select * from Book", con);
            //con.Open();
            //SqlDataReader dr = cmd.ExecuteReader();
            //books = new List<Book>();
            //while(dr.Read())
            //{
            //    books.Add(new Book
            //    {
            //        BookId = Convert.ToInt32(dr["BookId"]),
            //        BookName = dr["BookName"].ToString(),
            //        BookAuthor= dr["BookAuthor"].ToString(),
            //        BookCopies= Convert.ToInt32(dr["BookCopies"])
            //    });
            //}
            //con.Close();
            //return books;
            #endregion

            #region diisconnected approach
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from Book", con);
            DataTable dt = new DataTable();
            books = new List<Book>();
            adp.Fill(dt);
            if(dt!=null && dt.Rows.Count>0)
            {
                for(int i=0;i<dt.Rows.Count;i++)
                {
                    books.Add(new Book
                    {
                        BookId = Convert.ToInt32(dt.Rows[i]["BookId"]),
                        BookName = dt.Rows[i]["BookName"].ToString(),
                        BookAuthor= dt.Rows[i]["BookAuthor"].ToString(),
                        BookCopies= Convert.ToInt32(dt.Rows[i]["BookCopies"])
                    });
                }
            }

            ////how to serialize
            //XmlSerializer serializer = new XmlSerializer(typeof(List<Book>));
            //FileStream filestr = new FileStream("books.xml", FileMode.Create);
            //serializer.Serialize(filestr, books);

            ////how to deserialize
            //var reader = new StreamReader("books.xml");
            //var result = (List<Book>)

            return books;
            #endregion
        }
        public string RemoveBooksDAL(Book book)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Delete from Book where BookId="+book.BookId+";", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            msg = "Deleted";
            return msg;
            #endregion
        }
        public string UpdateBooksDal(Book book)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Update Book set BookAuthor='" + book.BookAuthor + "', BookCopies=" + book.BookCopies + ", BookId=" + book.BookId + ", BookName='" + book.BookName + "' where BookId="+book.BookId+";", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            msg = "Updated";
            return msg;
            #endregion
        }
    }
}
