﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagementEntity;
using LibraryManagementPresentation;

namespace LibraryManagement
{
    public class Program
    {
        static void Main(string[] args)
        {
            AdminPl adpl = new AdminPl();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to ABC Library Management System");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Login as Admin");
            Console.WriteLine("2) Press 2 to login as User");
            Console.WriteLine("3) Press 3 to exit");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        adpl.AdminLogin();
                        break;
                    }
                case 2:
                    adpl.AdminLogin();
                    break;
                case 3:
                    break;
            }

            if (input == 1)
            {
                adpl.AdminSection();
            }

            //Type type = typeof(Book);
            //var members= type.GetMembers();
            //var method = type.GetMethods();
            //var propInfo=type.GetProperties();
            //var t = "";
            //Activator
            Console.Read();
        }
    }
}
