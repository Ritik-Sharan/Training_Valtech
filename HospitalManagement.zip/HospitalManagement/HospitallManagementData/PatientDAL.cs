﻿using HospitallManagementEntity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitallManagementData
{
    public class PatientDAL
    {
        public static List<Patient> patients;
        public static string sqlcon = "Data Source=DESKTOP-4KMQLC8;Initial Catalog=HospitalManagement;Integrated Security=True;";

        public string AddPatientsDAL(Patient patient)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Insert into Patient values('" + patient.PatientEmail + "'," + patient.PatientId + ",'" + patient.PatientName + "','" + patient.PatientPassword + "')", con);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            adp.Fill(dt);

            msg = "Inserted";
            return msg;
            #endregion

        }
        public string UpdatePatientDal(Patient patient)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Update Patient set PatientEmail='" + patient.PatientEmail + "', PatientId=" + patient.PatientId + ", PatientName='" + patient.PatientName + "', PatientPassword='" + patient.PatientPassword + "' where PatientId=" + patient.PatientId + ";", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            msg = "Updated";
            return msg;
            #endregion
        }
        public string RemovePatientDAL(Patient patient)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Delete from Patient where PatientId=" + patient.PatientId + ";", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            msg = "Deleted";
            return msg;
            #endregion
        }
        public List<Patient> GetAllPatientsDAL()
        {
            #region diisconnected approach
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from Patient", con);
            DataTable dt = new DataTable();
            patients = new List<Patient>();
            adp.Fill(dt);
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    patients.Add(new Patient
                    {
                        PatientId = Convert.ToInt32(dt.Rows[i]["PatientId"]),
                        PatientName = dt.Rows[i]["PatientName"].ToString(),
                        PatientPassword = dt.Rows[i]["PatientPassword"].ToString(),
                        PatientEmail = dt.Rows[i]["PatientEmail"].ToString()
                    });
                }
            }
            return patients;
            #endregion
        }
    }
}
