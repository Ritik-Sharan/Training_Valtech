﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagementEntity;
using HospitallManagementEntity;

namespace HospitallManagementData
{
    public class DoctorDAL
    {
        public static List<Doctor> doctors;
        public static string sqlcon = "Data Source=DESKTOP-4KMQLC8;Initial Catalog=HospitalManagement;Integrated Security=True;";

        public string AddBooksDAL(Doctor doctor)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Insert into Doctor values('" + doctor.DoctorEmail + "'," + doctor.DoctorId + ",'" + doctor.DoctorName + "','" + doctor.DoctorPassword + "')", con);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            adp.Fill(dt);

            msg = "Inserted";
            return msg;
            #endregion

        }
        public string UpdateDoctorDal(Doctor doctor)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Update Doctor set DoctorEmail='" + doctor.DoctorEmail + "', DoctorId=" + doctor.DoctorId + ", DoctorName='" + doctor.DoctorName + "', DoctorPassword='" + doctor.DoctorPassword + "' where DoctorId=" + doctor.DoctorId + ";", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            msg = "Updated";
            return msg;
            #endregion
        }
        public string RemoveDoctorDAL(Doctor doctor)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Delete from Doctor where DoctorId=" + doctor.DoctorId + ";", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            msg = "Deleted";
            return msg;
            #endregion
        }
        public List<Doctor> GetAllDoctorsDAL()
        {
            #region diisconnected approach
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from Doctor", con);
            DataTable dt = new DataTable();
            doctors = new List<Doctor>();
            adp.Fill(dt);
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    doctors.Add(new Doctor
                    {
                        DoctorId = Convert.ToInt32(dt.Rows[i]["DoctorId"]),
                        DoctorName = dt.Rows[i]["DoctorName"].ToString(),
                        DoctorPassword = dt.Rows[i]["DoctorPassword"].ToString(),
                        DoctorEmail = dt.Rows[i]["DoctorEmail"].ToString()
                    });
                }
            }
            return doctors;
            #endregion
        }
    }
}
