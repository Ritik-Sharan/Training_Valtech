﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagementPresentation;

namespace HotelManagement
{
    public class Program
    {
        static void Main(string[] args)
        {
            AdminPL adpl = new AdminPL();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Hospital Management System");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Login as Admin");
            Console.WriteLine("2) Press 2 to login as Doctor");
            Console.WriteLine("2) Press 3 to login as User");
            Console.WriteLine("3) Press 4 to exit");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        adpl.AdminLogin();
                        break;
                    }
                case 2:
                    adpl.AdminLogin();
                    break;
                case 3:
                    break;
            }

            if (input == 1)
            {
                adpl.AdminSection();
            }
            Console.Read();
        }
    }
}
