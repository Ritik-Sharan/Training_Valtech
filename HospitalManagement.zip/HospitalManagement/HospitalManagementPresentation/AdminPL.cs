﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitallManagementEntity;
using HospitalManagementBussiness;

namespace HospitalManagementPresentation
{
    public class AdminPL
    {
        private void GetAdminMenu()
        {
            DoctorPL doctorpl=new DoctorPL();
            PatientPL patientpl=new PatientPL();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Admin-Section----------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to show Doctor section");
            Console.WriteLine("2) Press 2 to show Patient section");
            Console.WriteLine("3) Press 3 to show Patient-History section");
            Console.WriteLine("3) Press 4 to show Billing section");
            Console.Write("3) Press 5 to ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("logout");
            Console.ForegroundColor = ConsoleColor.White;
            var input = Convert.ToInt32(Console.ReadLine());
            switch (input)
            {
                case 1:
                    {
                        doctorpl.DoctorSection();
                        AdminSection();
                        break;
                    }
                case 2:
                    {
                        patientpl.PatientSection();
                        AdminSection();
                        break;
                    }
                //case 3:
                //    {
                //        RemoveDoctor();
                //        DoctorSection();
                //        break;
                //    }
                //case 4:
                //    {
                //        GetAllDoctor();
                //        DoctorSection();
                //        break;
                //    }
                case 5:
                    {
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Invalid Input, try again");
                        AdminSection();
                        break;
                    }
            }
        }
        public bool AdminLogin()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Admin-Login----------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Enter Admin Email : ");
            string email = Console.ReadLine();
            Console.Write("Enter Admin Password : ");
            string password = Console.ReadLine();

            AdminBLL bll = new AdminBLL();
            bool status = bll.AdminLogin(email, password);

            if (status)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Successfully logged in !!");
            }
            else
                Console.WriteLine("Invalid Credentials");
            return status;
        }
        public bool AdminSection()
        {
            GetAdminMenu();
            return true;
        }
    }
}
