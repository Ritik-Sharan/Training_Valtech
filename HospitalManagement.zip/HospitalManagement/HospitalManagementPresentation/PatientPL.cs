﻿using HospitallManagementEntity;
using HospitalManagementBussiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementPresentation
{
    public class PatientPL
    {
        public string PatientSection()
        {
            AdminPL adminPL=new AdminPL();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Patient-Section----------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to add a Patient detail");
            Console.WriteLine("2) Press 2 to update a Patient detail");
            Console.WriteLine("3) Press 3 to delete a Patient detail");
            Console.WriteLine("4) Press 4 to show all Patient detail");
            Console.WriteLine("5) Press 5 to return to Admin-menu");
            var input = Convert.ToInt32(Console.ReadLine());


            switch (input)
            {
                case 1:
                    {
                        AddPatient();
                        PatientSection();
                        break;
                    }
                case 2:
                    {
                        UpdatePatient();
                        PatientSection();
                        break;
                    }
                case 3:
                    {
                        RemovePatient();
                        PatientSection();
                        break;
                    }
                case 4:
                    {
                        GetAllPatient();
                        PatientSection();
                        break;
                    }
                case 5:
                    {
                        adminPL.AdminSection();
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Invalid Input, try again");
                        PatientSection();
                        break;
                    }
                    

            }
            return "";
        }
        public void AddPatient()
        {
            Patient patient = new Patient();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Patient details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter Patient E-mail : ");
            patient.PatientEmail = Console.ReadLine();
            Console.WriteLine("Enter Patient Id : ");
            patient.PatientId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Patient Name : ");
            patient.PatientName = Console.ReadLine();
            Console.WriteLine("Enter Patient Password : ");
            patient.PatientPassword = Console.ReadLine();

            PatientBLL patientBLL = new PatientBLL();
            string msg = patientBLL.AddPatientBll(patient);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Patient detail added successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void UpdatePatient()
        {
            Patient patient = new Patient();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Patient details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter Patient E-mail : ");
            patient.PatientEmail = Console.ReadLine();
            Console.WriteLine("Enter Patient Id : ");
            patient.PatientId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Patient Name : ");
            patient.PatientName = Console.ReadLine();
            Console.WriteLine("Enter Patient Password : ");
            patient.PatientPassword = Console.ReadLine();

            PatientBLL patientBLL=new PatientBLL();
            string msg = patientBLL.UpdatePatientBll(patient);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Patient detail updated successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void RemovePatient()
        {
            Patient patient = new Patient();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Patient details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter Patient Id : ");
            patient.PatientId = Convert.ToInt32(Console.ReadLine());

            PatientBLL patientBLL = new PatientBLL();
            string msg = patientBLL.RemovePatientBLL(patient);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Patient detail removed successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void GetAllPatient()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("------------------------------------Patient-List----------------------------------");
            Console.WriteLine("--Id----Name----------------------------E-mail--------------------------Password--");
            Console.ForegroundColor = ConsoleColor.White;

            PatientBLL patientBLL = new PatientBLL();
            List<Patient> patients = patientBLL.GetAllPatientBll();
            foreach (var item in patients)
            {
                Console.WriteLine("  " + item.PatientId + "\t" + item.PatientName + "\t" + item.PatientEmail + "\t" + item.PatientPassword);
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("----------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
