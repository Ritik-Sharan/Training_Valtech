﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitallManagementEntity;
using HospitalManagementBussiness;
using HospitalManagementEntity;

namespace HospitalManagementPresentation
{
    public class DoctorPL
    {
        public string DoctorSection()
        {
            AdminPL adminPL = new AdminPL();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Doctor-Section----------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to add a Doctor detail");
            Console.WriteLine("2) Press 2 to update a Doctor detail");
            Console.WriteLine("3) Press 3 to delete a Doctor detail");
            Console.WriteLine("4) Press 4 to show all Doctor detail");
            Console.WriteLine("5) Press 5 to return to Admin-menu");
            var input = Convert.ToInt32(Console.ReadLine());


            switch (input)
            {
                case 1:
                    {
                        AddDoctor();
                        DoctorSection();
                        break;
                    }
                case 2:
                    {
                        UpdateDoctor();
                        DoctorSection();
                        break;
                    }
                case 3:
                    {
                        RemoveDoctor();
                        DoctorSection();
                        break;
                    }
                case 4:
                    {
                        GetAllDoctor();
                        DoctorSection();
                        break;
                    }
                case 5:
                    {
                        adminPL.AdminSection();
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Invalid Input, try again");
                        DoctorSection();
                        break;
                    }
            }
            return "";
        }
        public void AddDoctor()
        {
            Doctor doctor = new Doctor();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Doctor details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter Doctor E-mail : ");
            doctor.DoctorEmail = Console.ReadLine();
            Console.WriteLine("Enter Doctor Id : ");
            doctor.DoctorId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Doctor Name : ");
            doctor.DoctorName = Console.ReadLine();
            Console.WriteLine("Enter Doctor Password : ");
            doctor.DoctorPassword = Console.ReadLine();

            DoctorBLL doctorBLL = new DoctorBLL();
            string msg = doctorBLL.AddDoctorBll(doctor);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Doctor detail added successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void UpdateDoctor()
        {
            Doctor doctor = new Doctor();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Doctor details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter Doctor E-mail : ");
            doctor.DoctorEmail = Console.ReadLine();
            Console.WriteLine("Enter Doctor Id : ");
            doctor.DoctorId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Doctor Name : ");
            doctor.DoctorName = Console.ReadLine();
            Console.WriteLine("Enter Doctor Password : ");
            doctor.DoctorPassword = Console.ReadLine();

            DoctorBLL doctorBLL = new DoctorBLL();
            string msg = doctorBLL.UpdateDoctorBll(doctor);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Doctor detail updated successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void RemoveDoctor()
        {
            Doctor doctor= new Doctor();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter Doctor details...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Enter Doctor Id : ");
            doctor.DoctorId = Convert.ToInt32(Console.ReadLine());

            DoctorBLL doctorBLL= new DoctorBLL();
            string msg = doctorBLL.RemoveDoctorBLL(doctor);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Doctor details deleted successfully !");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void GetAllDoctor()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("------------------------------------Doctor-List-----------------------------------");
            Console.WriteLine("--Id----Name----------------------------E-mail--------------------------Password--");
            Console.ForegroundColor = ConsoleColor.White;

            DoctorBLL doctorBLL = new DoctorBLL();
            List<Doctor> doctors = doctorBLL.GetAllDoctorBll();
            foreach (var item in doctors)
            {
                Console.WriteLine("  " + item.DoctorId + "\t" + item.DoctorName + "\t" + item.DoctorEmail + "\t" + item.DoctorPassword);
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("----------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
