﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitallManagementEntity
{
    public class Patient
    {
        public string PatientEmail { get; set; }
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string PatientPassword { get; set; }
        public Patient()
        {

        }
    }
}
