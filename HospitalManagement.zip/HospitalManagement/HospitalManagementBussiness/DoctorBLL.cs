﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitallManagementData;
using HospitallManagementEntity;
using HospitalManagementData;
using HospitalManagementEntity;

namespace HospitalManagementBussiness
{
    public class DoctorBLL
    {
        public static List<Doctor> doctors;
        DoctorDAL docdal= new DoctorDAL();

        public string AddDoctorBll(Doctor doctors)
        {
            return docdal.AddBooksDAL(doctors);
        }
        public string UpdateDoctorBll(Doctor doctors)
        {
            return docdal.UpdateDoctorDal(doctors);
        }
        public string RemoveDoctorBLL(Doctor doctors)
        {
            return docdal.RemoveDoctorDAL(doctors);
        }
        public List<Doctor> GetAllDoctorBll()
        {
            return docdal.GetAllDoctorsDAL();
        }
    }
}
