﻿using HospitallManagementData;
using HospitallManagementEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementBussiness
{
    public class PatientBLL
    {
        public static List<Patient> doctors;
        PatientDAL patientDAL = new PatientDAL();

        public string AddPatientBll(Patient patient)
        {
            return patientDAL.AddPatientsDAL(patient);
        }
        public string UpdatePatientBll(Patient patient)
        {
            return patientDAL.UpdatePatientDal(patient);
        }
        public string RemovePatientBLL(Patient patient)
        {
            return patientDAL.RemovePatientDAL(patient);
        }
        public List<Patient> GetAllPatientBll()
        {
            return patientDAL.GetAllPatientsDAL();
        }
    }
}
