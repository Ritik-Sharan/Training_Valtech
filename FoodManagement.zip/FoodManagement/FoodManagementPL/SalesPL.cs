﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPL
{
    public class SalesPL
    {
        public void SalesMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Sales Menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To add new sales");
            Console.WriteLine("2) To edit existing sales ");
            Console.WriteLine("3) To view details of sales ");
            Console.WriteLine("4) To list the sales");
            Console.WriteLine("5) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {

            }
        }
    }
}
