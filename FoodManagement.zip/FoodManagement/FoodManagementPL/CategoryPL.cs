﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPL
{
    public class CategoryPL
    {
        public void CategoryMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Food-Category menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To add new food category");
            Console.WriteLine("2) To edit existing food category ");
            Console.WriteLine("3) To view details of food category ");
            Console.WriteLine("4) To list the food category");
            Console.WriteLine("5) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {

            }
        }
    }
}
