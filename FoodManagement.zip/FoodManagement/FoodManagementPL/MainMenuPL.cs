﻿using System;

namespace FoodManagementPL
{
    public class MainMenuPL
    {
        ItemsPL itemsPL = new ItemsPL();
        CategoryPL categoryPL = new CategoryPL();
        SalesPL salesPL = new SalesPL();
        ReportsPL reportsPL = new ReportsPL();
        public void MainMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Food_Management_Court ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To manage food items");
            Console.WriteLine("2) To manage food category");
            Console.WriteLine("3) To manage sales");
            Console.WriteLine("4) To get Reports of the Food_Management_Court");
            Console.WriteLine("5) To return to Logout",Console.ForegroundColor=ConsoleColor.Red);
            Console.ForegroundColor = ConsoleColor.White;

            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        itemsPL.ItemMenu();
                        MainMenu();
                        break;
                    }
                case 2:
                    {
                        categoryPL.CategoryMenu();
                        MainMenu();
                        break;
                    }
                case 3:
                    {
                        salesPL.SalesMenu();
                        MainMenu();
                        break;
                    }
                case 4:
                    {
                        reportsPL.ReportMenu();
                        MainMenu();
                        break;
                    }
            }
        }
    }
}
