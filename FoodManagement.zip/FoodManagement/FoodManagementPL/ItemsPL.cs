﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPL
{
    public class ItemsPL
    {
       public void ItemMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Food-Item Menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To add new food items");
            Console.WriteLine("2) To edit existing food items ");
            Console.WriteLine("3) To view details of food items ");
            Console.WriteLine("4) To list the food items");
            Console.WriteLine("5) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                
            }
        }
    }
}
