﻿using FoodManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;

namespace FoodManagementDAL
{
    public class FoodManagementDB : DbContext
    {
        public DbSet<Item> items { get; set; }
        public DbSet<Category> categories { get; set; }
        public DbSet<Sales> sales { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {
            dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LLAP2298;Initial Catalog=FoodManagementDB;Integrated Security=True;");

        }
    }
}
