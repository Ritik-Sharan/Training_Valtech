﻿using FoodManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementDAL
{
    public class FoodDbOperations
    {
        FoodManagementDB db = new FoodManagementDB();   

    }
}
