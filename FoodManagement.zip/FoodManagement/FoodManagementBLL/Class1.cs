﻿using System;

namespace FoodManagementBLL
{
    public class Class1
    {
    }
}
