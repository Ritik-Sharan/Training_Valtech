﻿using FoodManagementDAL;
using FoodManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementBLL
{
    public class SalesBLL
    {
        public static List<Sales> Items;
        SaleOperation saleOperation = new SaleOperation();
        public string AddSalesBLL(Sales sales)
        {
            return saleOperation.AddSales(sales);
        }
        public string EditSalesBLL(Sales sales)
        {
            return saleOperation.EditSales(sales);
        }
        public List<Sales> ShowAllBLL()
        {
            return saleOperation.ShowAll();
        }
    }
}
