﻿using FoodManagementDAL;
using FoodManagementEntity;
using System;
using System.Collections.Generic;

namespace FoodManagementBLL
{
    public class ItemBLL
    {
        public static List<Item> Items;
        ItemOperations ItemOperations = new ItemOperations();
        public string AddItemBLL(Item Item)
        {
            return ItemOperations.AddItem(Item);
        }
        public string EditItemBLL(Item Item)
        {
            return ItemOperations.EditItem(Item);
        }
        public List<Item> ShowAllBLL()
        {
            return ItemOperations.ShowAll();
        }
        
    }
}
