﻿using FoodManagementDAL;
using FoodManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementBLL
{
    public class CategoryBLL
    {
        public static List<Category> categories;
        CategoryOperation categoryOperation = new CategoryOperation();
        public string AddCategoryBLL(Category category)
        {
            return categoryOperation.AddCategory(category);
        }
        public string EditCategoryBLL(Category category)
        {
            return categoryOperation.EditCategory(category);
        }
        public List<Category> ShowAllBLL()
        {
            return categoryOperation.ShowAll();
        }
    }
}
