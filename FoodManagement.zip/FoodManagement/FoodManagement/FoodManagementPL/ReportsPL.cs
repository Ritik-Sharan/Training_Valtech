﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPL
{
    public class ReportsPL
    {
        public void ReportMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Report-details Menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To report all food items");
            Console.WriteLine("2) To report all food category ");
            Console.WriteLine("3) To report all sales ");
            Console.WriteLine("4) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {

            }
        }
    }
}
