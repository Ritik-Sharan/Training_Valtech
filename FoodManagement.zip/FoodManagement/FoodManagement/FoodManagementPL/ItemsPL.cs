﻿using System;
using System.Collections.Generic;
using System.Text;
using FoodManagementEntity;
using FoodManagementBLL;

namespace FoodManagementPL
{
    public class ItemsPL
    {
        Item item = new Item();
        ItemBLL itemBLL = new ItemBLL();
        MainMenuPL mainMenuPL = new MainMenuPL();
        public void ItemMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Food-Item Menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To add new food items");
            Console.WriteLine("2) To edit existing food items ");
            Console.WriteLine("3) To view details of food items ");
            Console.WriteLine("4) To list the food items");
            Console.WriteLine("5) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        AddItemPL();
                        ItemMenu();
                        break;
                    }
                case 2:
                    {
                        EditItemsPL();
                        ItemMenu();
                        break;
                    }
                case 3:
                    {
                        ShowAllItemsPL();
                        ItemMenu();
                        break;
                    }
                case 4:
                    {
                        ItemMenu();
                        break;
                    }
                case 5:
                    {
                        mainMenuPL.MainMenu();
                        break;
                    }

            }
        }

        public void AddItemPL()
        {
            Console.WriteLine("Enter Item Name : ");
            item.Name = Console.ReadLine();
            Console.WriteLine("Enter Item Type : ");
            item.Type = Console.ReadLine();
            Console.WriteLine("Enter Item Price : ");
            item.Price = Convert.ToInt32(Console.ReadLine());

            itemBLL.AddItemBLL(item);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("New Item added successfully!");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void EditItemsPL()
        {
            Console.Write("Enter Item Id:");
            item.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter Item Name:");
            item.Name = Console.ReadLine();
            Console.Write("Enter Item Type:");
            item.Type = Console.ReadLine();
            Console.WriteLine("Enter Item Price : ");
            item.Price = Convert.ToInt32(Console.ReadLine());

            itemBLL.EditItemBLL(item);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Item Updated Successfully............");
            Console.ForegroundColor = ConsoleColor.White;

        }
        public void ShowAllItemsPL()
        {
            List<Item> Items = itemBLL.ShowAllBLL();
            foreach (var amt in Items)
            {
                Console.WriteLine("Item Id : " + item.Id);
                Console.WriteLine("Item Name : " + item.Name);
                Console.WriteLine("Item Type : " + item.Type);
                Console.WriteLine("Item Price : " + item.Price);
            }
        }
    }
}
