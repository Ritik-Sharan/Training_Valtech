﻿using FoodManagementBLL;
using FoodManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPL
{
    public class CategoryPL
    {
        Category category = new Category();
        CategoryBLL categoryBLL = new CategoryBLL();
        MainMenuPL mainMenuPL = new MainMenuPL();
        public void CategoryMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Food-Category menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To add new food category");
            Console.WriteLine("2) To edit existing food category ");
            Console.WriteLine("3) To view details of food category ");
            Console.WriteLine("4) To list the food category");
            Console.WriteLine("5) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        AddCategoryPL();
                        CategoryMenu();
                        break;
                    }
                case 2:
                    {
                        EditCategoryPL();
                        CategoryMenu();
                        break;
                    }
                case 3:
                    {
                        ShowAllCategoryPL();
                        CategoryMenu();
                        break;
                    }
                case 4:
                    {
                        CategoryMenu();
                        break;
                    }
                case 5:
                    {
                        mainMenuPL.MainMenu();
                        break;
                    }
            }
        }
        public void AddCategoryPL()
        {

            Console.WriteLine("Enter Item Id : ");
            category.ItemId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Category Name : ");
            category.Name = Console.ReadLine();

            categoryBLL.AddCategoryBLL(category);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("New Category added successfully!");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void EditCategoryPL()
        {
            Console.Write("Enter Category Id:");
            category.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter Item Id:");
            category.ItemId = int.Parse(Console.ReadLine());
            Console.Write("Enter Category Name:");
            category.Name = Console.ReadLine();

            categoryBLL.EditCategoryBLL(category);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Category Updated Successfully............");
            Console.ForegroundColor = ConsoleColor.White;

        }
        public void ShowAllCategoryPL()
        {
            List<Category> categories = categoryBLL.ShowAllBLL();
            foreach (var cat in categories)
            {
                Console.WriteLine("Category Id : " + category.Id);
                Console.WriteLine("Item Id : " + category.ItemId);
                Console.WriteLine("Category Name : " + category.Name);
            }
        }
    }
}
