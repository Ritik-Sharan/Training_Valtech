﻿using FoodManagementBLL;
using FoodManagementEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodManagementPL
{
    public class SalesPL
    {
        MainMenuPL mainMenuPL = new MainMenuPL();
        SalesBLL salesBLL = new SalesBLL();
        Sales sales = new Sales();
        public void SalesMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Welcome to Sales Menu ----------!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) To add new sales");
            Console.WriteLine("2) To edit existing sales ");
            Console.WriteLine("3) To view details of sales ");
            Console.WriteLine("4) To list the sales");
            Console.WriteLine("5) To return to main-menu");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        AddSalesPL();
                        SalesMenu();
                        break;
                    }
                case 2:
                    {
                        EditSalesPL();
                        SalesMenu();
                        break;
                    }
                case 3:
                    {
                        ShowAllSalesPL();
                        SalesMenu();
                        break;
                    }
                case 4:
                    {
                        SalesMenu();
                        break;
                    }
                case 5:
                    {
                        mainMenuPL.MainMenu();
                        break;
                    }
            }
        }
        public void AddSalesPL()
        {
            Console.WriteLine("Enter Item Id : ");
            sales.ItemId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Quantity : ");
            sales.Quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Sales cost : ");
            sales.SalesCost = Convert.ToInt32(Console.ReadLine());

            salesBLL.AddSalesBLL(sales);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("New Sale added successfully!");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void EditSalesPL()
        {
            Console.WriteLine("Enter Sales Id : ");
            sales.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Id : ");
            sales.ItemId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Quantity : ");
            sales.Quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Sales cost : ");
            sales.SalesCost = Convert.ToInt32(Console.ReadLine());

            salesBLL.EditSalesBLL(sales); 
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Category Updated Successfully............");
            Console.ForegroundColor = ConsoleColor.White;

        }
        public void ShowAllSalesPL()
        {
            List<Sales> sale = salesBLL.ShowAllBLL();
            foreach (var sal in sale)
            {
                Console.WriteLine("Sales Id : " + sales.Id);
                Console.WriteLine("Item Id : " + sales.ItemId);
                Console.WriteLine("Quantity : " + sales.Quantity);
                Console.WriteLine("Sales Cost : " + sales.SalesCost);
            }
        }
    }
}
