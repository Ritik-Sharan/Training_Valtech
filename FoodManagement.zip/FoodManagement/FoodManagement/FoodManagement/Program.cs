﻿using FoodManagementPL;
using System;

namespace FoodManagement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            MainMenuPL mainMenuPL = new MainMenuPL();
            mainMenuPL.MainMenu();
        }
    }
}
