﻿using FoodManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodManagementDAL
{
    public class ItemOperations
    {
        FoodManagementDB db = null;

        public string AddItem(Item items)
        {
            db = new FoodManagementDB();
            db.items.Add(items);
            db.SaveChanges();
            return "Added";
        }
        public string EditItem(Item items)
        {
            db = new FoodManagementDB();
            db.Entry(items).State = EntityState.Modified;
            db.SaveChanges();
            return "Updated";

        }
        public List<Item> ShowAll()
        {
            List<Item> allItems = db.items.ToList();
            return allItems;
        }
    }
}
