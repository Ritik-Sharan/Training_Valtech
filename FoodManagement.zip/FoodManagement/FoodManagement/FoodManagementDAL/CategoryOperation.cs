﻿using FoodManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodManagementDAL
{
    public class CategoryOperation
    {
        FoodManagementDB db = new FoodManagementDB();

        public string AddCategory(Category category)
        {
            db.categories.Add(category);
            db.SaveChanges();
            return "Added";
        }
        public string EditCategory(Category category)
        {
            db.Entry(category).State = EntityState.Modified;
            db.SaveChanges();
            return "Updated";

        }
        public List<Category> ShowAll()
        {
            List<Category> allCategories = db.categories.ToList();
            return allCategories;
        }
    }
}
