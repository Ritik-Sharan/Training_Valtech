﻿using FoodManagementEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodManagementDAL
{
    public class SaleOperation
    {
        FoodManagementDB db = new FoodManagementDB();

        public string AddSales(Sales sales)
        {
            db.sales.Add(sales);
            db.SaveChanges();
            return "Added";
        }
        public string EditSales(Sales sales)
        {
            db.Entry(sales).State = EntityState.Modified;
            db.SaveChanges();
            return "Updated";

        }
        public List<Sales> ShowAll()
        {
            List<Sales> allsales = db.sales.ToList();
            return allsales;
        }
    }
}
