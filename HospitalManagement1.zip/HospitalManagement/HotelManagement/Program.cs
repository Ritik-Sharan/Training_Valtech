﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagementPresentation;

namespace HotelManagement
{
    public class Program
    {
        static void Main(string[] args)
        {
            AdminPL adpl = new AdminPL();
            DoctorPL docpl = new DoctorPL();
            PatientPL patpl = new PatientPL();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"
-------------------------------------------------
------Welcome to Hospital Management System------
-------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1) Press 1 to Login as Admin");
            Console.WriteLine("2) Press 2 to login as Doctor");
            Console.WriteLine("2) Press 3 to login as Patient");
            Console.WriteLine("3) Press 4 to exit");
            var input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    {
                        adpl.AdminLogin();
                        break;
                    }
                case 2:
                    {
                        docpl.DoctorLogin();
                        break;
                    }
                case 3:
                    {
                        patpl.PatientLogin();
                        break;
                    }
            }

            switch (input)
            {
                case 1:
                    {
                        adpl.AdminSection();
                        break;
                    }
                case 2:
                    {
                        docpl.GetDoctorMenu();
                        break ;
                    }
                case 3:
                    {
                        patpl.GetPatientMenu();
                    }
                    break;
            }
            Console.Read();
        }
    }
}
