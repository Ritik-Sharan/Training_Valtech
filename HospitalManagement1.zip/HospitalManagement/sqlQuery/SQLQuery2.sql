create database LibraryManagement;
use LibraryManagement;

create table Admin_(
AdminEmail char(30),
AdminId numeric(15),
AdminName char(25),
AdminPassword char(25))

create table User_(
UserEmail char(30),
UserId numeric(15) primary key,
UserName char(25),
UserPassword char(25))

create table Book(
BookAuthor char(30),
BookCopies numeric(10),
BookId numeric(10) primary key,
BookName char(30))

create table ReceivedBook(
BookId numeric(10) references Book(BookId),
BookName char(30),
DateReceived date,
UserId numeric(15) references User_(UserId),
UserName char(25))

create table RequestedBook(
BookId numeric(10) references Book(BookId),
BookName char(30),
DateRequested date,
UserId numeric(15) references User_(UserId),
UserName char(25))

select * from Book;

update Book set BookAuthor='qqqqq',BookCopies=99,BookId=3,BookName='hhhhh' 
where BookId=3;

delete from Book where BookId=1234;

create database HospitalManagement;


