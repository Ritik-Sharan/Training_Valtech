use HospitalManagement

create table Admin_(
AdminEmail char(30),
AdminId numeric(15) primary key,
AdminName char(25),
AdminPassword char(25))
select * from patient
create table Doctor(
DoctorEmail char(30),
DoctorId numeric(15) primary key,
DoctorName char(25),
DoctorPassword char(25))

create table Patient(
PatientEmail char(30),
PatientId numeric(15) primary key,
PatientName char(25),
PatientPassword char(25))

create table PatientHistory(
PatientId numeric(15) references Patient(PatientId),
DOJ date,
DOD date,
Disease char(25),
Medicine char(25));

create table Prescription(
PatientId numeric(15) references Patient(PatientId),
DoctorId numeric(15) references Doctor(DoctorId),
Disease char(25),
Medicine char(25),
Duration_InDays numeric(10));

create table Rooms(
PatientId numeric(15) references Patient(PatientId),
DoctorId numeric(15) references Doctor(DoctorId),
Disease char(25),
RoomNo numeric(5),
FloorNo numeric(5));

create table Appointment(
AppointmentId numeric(15) primary key,
DoctorId numeric(15) references Doctor(DoctorId),
PatientId numeric(15) references Patient(PatientId),
PatientName char(25),
Disease char(20),
DOA char(25));

create table NewAppointment(
AppointmentId numeric(15) references Appointment(AppointmentId),
DoctorId numeric(15) references Doctor(DoctorId),
PatientId numeric(15) references Patient(PatientId),
PatientName char(25),
Disease char(20),
DOA char(25));

drop table Appointment
drop table NewAppointment
select * from Appointment
select * from NewAppointment


create table Billing(
AdminId numeric(15) references Admin_(AdminId),
PatientId numeric(15),
PatientName char(25),
TotalCost numeric);
