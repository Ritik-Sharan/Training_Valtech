﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagementData;
using HospitalManagementEntity;

namespace HospitalManagementBussiness
{
    public class AdminBLL
    {
        public bool AdminLogin(string AdminEmail, string AdminPassword)
        {
            bool flag = false;

            AdminDAL adminDAL = new AdminDAL();
            adminDAL.GetAllAdminsDAL();
            List<Admin> admins = adminDAL.GetAllAdminsDAL();

            foreach (Admin adobj in admins)
            {
                if (adobj.AdminEmail == AdminEmail && adobj.AdminPassword == AdminPassword)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }
    }
}
