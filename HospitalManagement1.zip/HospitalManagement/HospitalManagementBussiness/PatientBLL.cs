﻿using HospitallManagementData;
using HospitallManagementEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementBussiness
{
    public class PatientBLL
    {
        public static List<Patient> patients;
        PatientDAL patientDAL = new PatientDAL();

        public string AddPatientBll(Patient patient)
        {
            return patientDAL.AddPatientsDAL(patient);
        }
        public string UpdatePatientBll(Patient patient)
        {
            return patientDAL.UpdatePatientDal(patient);
        }
        public string RemovePatientBLL(Patient patient)
        {
            return patientDAL.RemovePatientDAL(patient);
        }
        public List<Patient> GetAllPatientBll()
        {
            return patientDAL.GetAllPatientsDAL();
        }
        public bool PatientLogin()
        {
            bool flag = false;

            Patient patient = new Patient();
            PatientDAL patientDAL = new PatientDAL();
            patientDAL.GetAllPatientsDAL();
            List<Patient> patients = patientDAL.GetAllPatientsDAL();

            foreach (Patient docobj in patients)
            {
                if (docobj.PatientEmail == patient.PatientEmail && docobj.PatientPassword == patient.PatientPassword)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }
    }
}
