﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagementEntity;

namespace HospitalManagementData
{
    public class AdminDAL
    {
        public List<Admin> admins;

        public List<Admin> GetAllAdminsDAL()
        {
            admins = new List<Admin>();
            Admin adm1 = new Admin("abc@gmail.com", 123, "Rahul Gupta", "12345");
            admins.Add(adm1);
            Admin adm2 = new Admin("xyz@gmail.com", 124, "Suraj Gupta", "54321");
            admins.Add(adm2);

            return admins;
        }
    }
}
