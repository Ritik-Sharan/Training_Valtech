﻿using HospitallManagementEntity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitallManagementData
{
    public class AppointmentDAL
    {
        public static List<Appointment> appointments;
        public static string sqlcon = "Data Source=VDC01LLAP2298;Initial Catalog=HospitalManagement;Integrated Security=True;";


        public string AddNewAppointmentDAL(Appointment appointment)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Insert into Appointment values(" + appointment.AppointmentId + "," + appointment.DoctorId + "," + appointment.PatientId + ",'" + appointment.PatientName + "','" + appointment.Disease + "','" + appointment.DOA + "')", con);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            adp.Fill(dt);

            msg = "Inserted";
            return msg;
            #endregion

        }
        public string RemoveNewAppointmentDAL(Appointment appointment)
        {
            #region diisconnected approach
            var msg = "";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Delete from Appointment where AppointmentId=" + appointment.AppointmentId + ";", con);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            adp.Fill(dt);

            msg = "Deleted";
            return msg;
            #endregion

        }
        public List<Appointment> GetAllNewAppointmentDAL()
        {
            #region diisconnected approach
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from NewAppointment", con);
            DataTable dt = new DataTable();
            appointments = new List<Appointment>();
            adp.Fill(dt);
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    appointments.Add(new Appointment
                    {
                        AppointmentId = Convert.ToInt32(dt.Rows[i]["AppointmentId"]),
                        DoctorId = Convert.ToInt32(dt.Rows[i]["DoctorId"]),
                        PatientId = Convert.ToInt32(dt.Rows[i]["PatientId"]),
                        PatientName = dt.Rows[i]["PatientName"].ToString(),
                        Disease = dt.Rows[i]["Disesae"].ToString(),
                        DOA = dt.Rows[i]["DOA"].ToString()
                    });
                }
            }
            return appointments;
            #endregion
        }
        public List<Appointment> GetAllAppointmentDAL()
        {
            #region diisconnected approach
            SqlConnection con = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from Appointment", con);
            DataTable dt = new DataTable();
            appointments = new List<Appointment>();
            adp.Fill(dt);
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    appointments.Add(new Appointment
                    {
                        AppointmentId = Convert.ToInt32(dt.Rows[i]["AppointmentId"]),
                        DoctorId = Convert.ToInt32(dt.Rows[i]["DoctorId"]),
                        PatientId = Convert.ToInt32(dt.Rows[i]["PatientId"]),
                        PatientName = dt.Rows[i]["PatientName"].ToString(),
                        Disease = dt.Rows[i]["Disesae"].ToString(),
                        DOA = dt.Rows[i]["DOA"].ToString()
                    });
                }
            }
            return appointments;
            #endregion
        }

    }
}
